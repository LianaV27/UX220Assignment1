# Financial
- continue to have a class a term at Laurier