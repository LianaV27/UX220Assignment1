# Family
- go to Australia twice in the next five years to see my grand-daughter

<img src="https://intermountainhealthcare.org/_next/image?url=%2F-%2Fmedia%2Fimages%2Fintermountain-health%2Fblogs%2Fblog%2Fposts%2F2016%2F06%2Fbuilding-family-relationships-my-heart-challenge.ashx%3Fh%3D461%26iar%3D0%26w%3D700%26hash%3D745B93C428D5C42EF7FA57D5C16BAD91&w=1920&q=75" height="300"/>